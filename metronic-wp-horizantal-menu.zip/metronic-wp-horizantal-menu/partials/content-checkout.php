<div class="app-content flex-column-fluid" id="kt_app_content">
    <div class="container-xxl" id="kt_app_content_container">
        <div class="card card-flush shadow-sm">
            <div class="card-body">
                <?php echo do_shortcode('[woocommerce_checkout]'); ?>
            </div>
        </div>
    </div>
</div>
