<div class="doc-preview-container">
    <div class="doc-page">
        <div>
            <h2 class="text-center fw-bold mb-5 text-uppercase" style="font-size: 26px;"><?php echo str_replace([' Form', ' form'], '', get_the_title()); ?></h2>
            <div id="doc-preview-content" class="fs-6 lh-lg"></div>
        </div>

        <div class="text-center text-muted mt-auto pt-5" style="font-size: 12px;">
            Page 1 of 1
        </div>
    </div>
</div>